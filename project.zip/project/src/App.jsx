import PageOne from "./pages/page-one/PageOne";

export default function App() {
  return <PageOne />
}
