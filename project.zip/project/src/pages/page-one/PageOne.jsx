import Card from "../../components/Card";
import Header from "../../components/Header";

export default function PageOne() {
  return (
    <div className="w-[90%] mx-auto py-8">
      <Header />
      <div className="py-24 text-center">
        <p className="text-[20px] leading-[32px] font-[300]">Blog</p>
        <h1 className="text-[84px] font-[300]">Thoughts and words</h1>
      </div>
      <div className="flex justify-center gap-32 items-center">
        <img src="Rectangle 1270.svg" />
        <div>
          <p className="text-[16px] leading-[28px] text-[#777777]">
            <span className="font-bold text-black pr-4">Category</span> November
            22, 2021
          </p>
          <p className="text-[48px] leading-[72px] font-[300]">
            Pitch termsheet backing
          </p>
          <p className="text-[48px] leading-[72px] font-[300]">
            validation focus release
          </p>
          <div className="py-4 flex items-center gap-4">
            <img src="Ellipse 10.svg" />
            <p>Chandler Bing</p>
          </div>
        </div>
      </div>
      <div className="w-full bg-[#0A2640] h-[1px] mt-32"></div>
      <div className="py-24 w-[70%] mx-auto">
        <h2 className="text-[48px] leading-[72px] font-[300]">Latest news</h2>
        <div className="py-8 grid grid-cols-3 gap-8">
          <Card
            banner="./Rectangle 1.svg"
            text="Pitch termsheet backing validation focus release"
            user="Chandler Bing"
            eclipse={"./Ellipse 10.svg"}
          />
          <Card
            banner="./Rectangle 2.svg"
            text="Seed round direct mailing non-disclosure agreement graphical user interface rockstar."
            user="Rachel Green"
            eclipse={"./Ellipse 11.svg"}
          />
          <Card
            banner="./Rectangle 3.svg"
            text="Beta prototype sales iPad gen-z marketing network effects value proposition"
            user="Monica Geller"
            eclipse={"./Ellipse 12.svg"}
          />
          <Card
            banner="./Rectangle 4.svg"
            text="Pitch termsheet backing validation focus release."
            user="Chandler Bing"
            eclipse={"./Ellipse 10.svg"}
          />
          <Card
            banner="./Rectangle 5.svg"
            text="Seed round direct mailing non-disclosure agreement graphical user interface rockstar."
            user="Rachel Green"
            eclipse={"./Ellipse 11.svg"}
          />
          <Card
            banner="./Rectangle 6.svg"
            text="Beta prototype sales iPad gen-z marketing network effects value proposition"
            user="Monica Geller"
            eclipse={"./Ellipse 12.svg"}
          />
        </div>
        <div className="flex items-center justify-center w-full">
          <button className="px-8 py-4 !border-[4px] !border-[#0A2640] rounded-full w-48 text-[#0A2640] font-[600]">
            Load More
          </button>
        </div>
      </div>
      <div className="h-[391px] w-full bg-[#0A2640] relative rounded-lg flex items-center justify-center">
        <img src="Ellipse 9.svg" className="absolute top-0 right-0" />
        <div className="flex items-center justify-center flex-col z-10">
          <h3 className="leading-[72px] text-[48px] font-[300] text-white">
            An enterprise template to ramp
          </h3>
          <h3 className="leading-[72px] text-[48px] font-[300] text-white">
            up your company website
          </h3>
          <div className="flex gap-4 items-center py-8">
            <input
              placeholder="Your email address"
              className="w-[370px] h-[56px] rounded-full px-8"
            />
            <button className="bg-[#65E4A3] h-[60px] w-[210px] rounded-full">
              Start now
            </button>
          </div>
        </div>
      </div>
      <footer className="pt-48 flex justify-between">
        <div className="space-y-12">
          <img src="Logo.svg" className="" />
          <p className="text-[#777777] text-[16px] font-[300]">
            Social media validation business model
            <br />
            canvas graphical user interface launch
            <br /> party creative facebook iPad twitter.
          </p>
          <p className="text-[#777777] text-[16px] font-[300]">
            All rights reserved.
          </p>
        </div>
        <div className="flex space-x-32">
          <div className="space-y-8">
            <p className="leading-[32px] text-[20px] font-[700]">Landings</p>
            <div className="space-y-4">
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Home
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Products
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Services
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <p className="leading-[32px] text-[20px] font-[700]">Company</p>
            <div className="space-y-4">
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Home
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Careers{" "}
                <button className="bg-[#65E4A3] h-[30px] w-[84px] rounded-full text-[13px] text-[#000] font-[700]">
                  Start now!
                </button>
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Services
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <p className="leading-[32px] text-[20px] font-[700]">Resources</p>
            <div className="space-y-4">
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Blog
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Products
              </p>
              <p className="text-[20px] leading-[32px] font-[300] text-[#777777]">
                Services
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

