export default function Header() {
  return (
      <header className="flex justify-between items-center">
          <img src="./Logo.svg" />
          <nav>
                <ul className="flex items-center gap-12">
                    <li><a href="#">Product</a></li>
                    <li><a href="#">Services</a></li>
                  <li><a href="#">About</a></li>
                  <button className="p-2 border !border-[#111] rounded-full w-32">Log in</button>
                </ul>
          </nav>
    </header>
  )
}
