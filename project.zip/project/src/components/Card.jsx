import React from 'react'

export default function Card({banner, text, user, eclipse}) {
  return (
      <div className='w-[300px]'>
            <img src={banner} />
            <div>
                <p className="text-[16px] leading-[28px] text-[#777777] py-4">
                    <span className="font-bold text-black pr-4">Category</span> November
                    22, 2021
                </p>
                <p className="text-[20px] leading-[32px] font-[300]">
                    {text}
                </p>
                <div className="py-8 flex items-center gap-4">
                    <img src={eclipse} />
                    <p>{user}</p>
                </div>
            </div>
    </div>
  )
}
